﻿//WineMain.cs
//by Ann-Marie Bergström 2017-09-17
namespace WineApplication
{
    class WineMain
    {
        static void Main(string[] args)
        {
            Wine wineObj = new Wine(); // create new object of Wine class

            wineObj.Start(); // use object

        } //close Main
    } //close class
} //close namespace
