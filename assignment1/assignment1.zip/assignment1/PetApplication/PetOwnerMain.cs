﻿//PetOwnerMain.cs
//by Ann-Marie Bergström 2017-09-17

namespace PetApplication
{
    class PetOwnerMain
    {
        static void Main(string[] args)
        {
            Pet petObj = new Pet(); // create new object of Pet class

            petObj.Start(); // use object

        } //close Main
    } //close class
} //close namespace
